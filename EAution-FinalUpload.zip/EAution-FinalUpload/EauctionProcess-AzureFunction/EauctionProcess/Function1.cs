using System;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Host;
using Microsoft.Extensions.Logging;

namespace EauctionProcess
{
    public class Function1
    {
        private readonly ILogger<Function1> _logger;

        public Function1(ILogger<Function1> log)
        {
            _logger = log;
        }

        [FunctionName("Function1")]
        public async Task RunAsync([ServiceBusTrigger("byuerinfoadd", "subscriber", Connection = "ConnectionString")]string mySbMsg)
        {
            _logger.LogInformation($"C# ServiceBus topic trigger function processed message: {mySbMsg}");

            using (HttpClient client = new HttpClient())
            {
                //client.BaseAddress = new Uri("http://localhost:54741/");
                client.DefaultRequestHeaders.Accept.Clear();
                //  client.DefaultRequestHeaders.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));

                var data = new StringContent(mySbMsg, Encoding.UTF8, "application/json");
                HttpResponseMessage response = await client.PostAsync("https://eautionbuyer.azurewebsites.net/buyer", data);
            }
        }
    }
}
