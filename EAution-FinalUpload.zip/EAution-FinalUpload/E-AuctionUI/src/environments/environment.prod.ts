export const environment = {
  production: true,
  apiServer: 'https://eautionwrite.azurewebsites.net/',
  imagePath: 'http://auction.sharkdev.eu/api/images/',
  titlePrefix: 'Online Auction'
};
