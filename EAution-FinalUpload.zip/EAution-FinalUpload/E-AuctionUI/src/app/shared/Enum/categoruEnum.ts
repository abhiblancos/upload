export enum CategoryEnum {
  Painting,Ornament,Sculptor
}
