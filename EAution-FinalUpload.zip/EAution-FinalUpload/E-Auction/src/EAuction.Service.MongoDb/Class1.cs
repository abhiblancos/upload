﻿using System;

namespace EAuction.Service.MongoDb
{
    public class Class1
    {
    }
}
